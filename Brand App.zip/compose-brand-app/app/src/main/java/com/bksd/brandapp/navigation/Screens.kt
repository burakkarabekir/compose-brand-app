package com.bksd.brandapp.navigation

import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.Serializable

@Serializable
data object BrandListScreen: NavKey

@Serializable
data class BrandDetailScreen(
    val brandId: Int
): NavKey