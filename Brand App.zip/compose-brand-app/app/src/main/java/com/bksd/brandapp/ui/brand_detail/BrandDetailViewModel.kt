package com.bksd.brandapp.ui.brand_detail

import androidx.lifecycle.ViewModel

class BrandDetailViewModel : ViewModel() {
}