package com.bksd.brandapp.ui.brand_list

import androidx.lifecycle.ViewModel

class BrandListViewModel : ViewModel(){
}