package com.bksd.brandapp.ui.brand_list

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun BrandListScreenUi(
    onBrandSelected: (Int) -> Unit,
    modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier
        .fillMaxSize()
    ) {
        items(100) {
            Text("Brand Name $it", Modifier.clickable {
                onBrandSelected(it)
            })
        }
    }
    
}